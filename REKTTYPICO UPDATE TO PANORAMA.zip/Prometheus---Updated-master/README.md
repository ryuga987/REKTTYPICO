# Prometheus---Updated
ok jesus christ i guess i need to make this apparent.

the cheat is unstable, it can be fixed, now leave me alone.

on a sidenote:

don't put any aimbot keys to your mouse side/middle buttons.

 ̶s̶t̶u̶f̶f̶ ̶d̶o̶e̶s̶n̶'̶t̶ ̶s̶a̶v̶e̶ ̶(̶l̶i̶k̶e̶ ̶4̶ ̶t̶h̶i̶n̶g̶s̶)̶ (fixed i think)

spamming the fullupdate will (probably) cause a crash (uses cl_fullupdate)

i will be updating the paste every now and then (crash fixes, etc.)
