#pragma once
#include "SDK.h"

class LocalInfo
{
public:
	Vector PunchAns;
	int Choked;
	int Flags;
	Vector LastPos;
};